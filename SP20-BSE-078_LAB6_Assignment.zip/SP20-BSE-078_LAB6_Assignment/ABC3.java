package com.company;
public class ABC3 {
    public static int i;
    public String s;
    public static void displayStatic() {
        System.out.println("i:" + i);
    }
    public void display() {
        System.out.println("i:" + i);
        System.out.println("s:" + s);
    }
}
