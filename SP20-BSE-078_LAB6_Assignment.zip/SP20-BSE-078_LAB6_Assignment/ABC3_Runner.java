package com.company;
public class ABC3_Runner {
    public static void main(String[] args) {
        ABC3 a = new ABC3();
        a.display();
        ABC3.displayStatic();
    }
}
