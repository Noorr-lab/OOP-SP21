package com.company;
public class Calculator {
    public static int x; int y;
    public static int sum(int x, int y){
        return (x+y);
    }
    public static int multiply(int x, int y){
        return (x*y);
    }
    public static int divide(int x, int y){
        return (x/y);
    }
    public static double modulus(int x, int y){
        return (y%x);
    }
    public static double sin(double x){
        return (Math.sin(x));
    }
    public static double cos(double y){
        return (Math.cos(y));
    }
    public static double tan(double y){
        return (Math.tan(y));
    }




}
