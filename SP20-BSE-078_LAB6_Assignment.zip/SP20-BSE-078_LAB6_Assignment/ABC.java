package com.company;
public class ABC {
    static int Var1 = 77;
    String Var2;
}
