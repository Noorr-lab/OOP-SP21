package com.company;
public class ABC_runner {
    public static void main(String[] args) {
        ABC ob1 = new ABC ();
        ABC ob2 = new ABC ();
        ob1.Var1 = 88;
        ob1.Var2 = "I'm Object1";
        ob2.Var2 = "I'm Object2";
        System.out.println("ob1 integer:"+ob1.Var1);
        System.out.println("ob1 String:"+ob1.Var2);
        System.out.println("ob2 integer:"+ob2.Var1);
        System.out.println("ob2 String:"+ob2.Var2);
    }
}
